let images = [];

document.getElementById("fileInput").addEventListener("change", (e) => {
  const files = Array.from(e.target.files);

  files.forEach((file) => {
    const obj = {
      id: Date.now() + Math.random(),
      file: file,
      url: URL.createObjectURL(file),
    };
    images.push(obj);
  });

  updateGallery();
});

function updateGallery() {
  const gallery = document.getElementById("gallery");
  gallery.innerHTML = "";

  images.forEach((img) => {
    const div = document.createElement("div");
    div.className = "gallery-item";
    div.setAttribute("data-id", img.id);

    div.innerHTML = `
      <img src="${img.url}">
      <button class="remove-btn" onclick="removeImage(${img.id})">×</button>
    `;

    gallery.appendChild(div);
  });

  Sortable.create(gallery, {
    animation: 150,
    onEnd: () => {
      const ordered = Array.from(gallery.children).map(
        (item) => Number(item.dataset.id)
      );
      images.sort((a, b) => ordered.indexOf(a.id) - ordered.indexOf(b.id));
    },
  });
}

function removeImage(id) {
  images = images.filter((img) => img.id !== id);
  updateGallery();
}

document.getElementById("generateBtn").addEventListener("click", async () => {
  if (images.length === 0) {
    alert("Upload at least one image!");
    return;
  }

  document.getElementById("story").textContent = "Generating story...";

  const form = new FormData();
  images.forEach((img) => form.append("files", img.file));
  form.append("tone", document.getElementById("tone").value);

  try {
    const res = await fetch("http://127.0.0.1:8000/generate", {
      method: "POST",
      body: form,
    });

    const data = await res.json();
    document.getElementById("story").textContent = data.story;

  } catch (err) {
    document.getElementById("story").textContent =
      "Error connecting to backend!";
  }
});
